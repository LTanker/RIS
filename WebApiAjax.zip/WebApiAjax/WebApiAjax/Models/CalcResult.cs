﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApiAjax.Models
{
    public class CalcResult
    {
        public int Sum { get; set; }
        public int Difference { get; set; }
        public int Product { get; set; }
        public int Quotient { get; set; }
    }
}
